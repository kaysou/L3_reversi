# README #

### What is this repository for? ###

Jeu de Reversi pour le projet de representation de connaisances

### How do I get set up? ###

* Deployment instructions
Lancez le projet et ... 

* Writing tests
* Code review
* Other guidelines

### Github link ###

https://github.com/kaysou/L3_reversi

### Contribution guidelines ###
Séance 1 :
	Yoan FATH et Jonathan SCHMITT
	- Mise en place du projet
	- Initialisation du depôt github
	- Mise en place du jeu et affichage
	- Mise en place des états sans successeurs
	- Enumération de positions pour faciliter le placement des coups

Séance 2 :
