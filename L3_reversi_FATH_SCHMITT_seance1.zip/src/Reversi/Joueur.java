package Reversi;

public abstract class Joueur {

}
