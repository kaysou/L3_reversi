package Reversi;

public class Principale {

	public static void main(String[] args) {
		Jeu j = new Jeu(8);
		System.out.print(j.afficherPlateau(j.getJeu()));

	}

}
