package Reversi;

public abstract class Etat {

	public abstract void successeur();
	public abstract void lireEtat();
	public abstract void ecrireEtat();
}
